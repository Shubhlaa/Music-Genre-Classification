# Music_Genre
Using deep learning to classify music genres and create music
